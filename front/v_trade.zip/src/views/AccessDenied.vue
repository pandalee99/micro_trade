<template>
    <Header></Header>
</template>

<script>
    import Header from "@/components/Header";
    export default {
        name: "AccessDenied",
        components: {Header}
    }
</script>

<style scoped>

</style>